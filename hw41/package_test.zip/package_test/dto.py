from typing import NamedTuple


class FuncParamDTO(NamedTuple):
    url: str
    filepath: str
    minutes: int
    sort_field: str
    sort_reverse: bool
    per_page: int
