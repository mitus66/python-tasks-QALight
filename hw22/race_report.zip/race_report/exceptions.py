class OrderError(Exception):
    pass
