EpisodesType = list[dict]
EpisodesPaginatedType = list[EpisodesType]

