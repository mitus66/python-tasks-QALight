import argparse

from main import main as domain_interface, OrderError


def parse_cli_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog='CLI Interface for Race report app.',
        usage='%(prog)s cli.py "--files "<folder path>" [--asc|--desc] [--driver <driver_name>]',
        description='Show report about Monaco race'
    )
    parser.add_argument('--files',
                        metavar='-f',
                        type=str,
                        help='path to folder with txt files',
                        required=True)

    parser.add_argument('--asc',
                        action='store_true',
                        help='order by ascending',
                        default=False,
                        required=False)

    parser.add_argument('--desc',
                        action='store_true',
                        help='order by descending',
                        default=False,
                        required=False)

    parser.add_argument('--driver',
                        help='show statistic about driver',
                        default='',
                        required=False)

    args = parser.parse_args()
    return args


def main(folder: str, order_asc: bool = True, order_desc: bool = False, driver: str = ''):
    try:
        result = domain_interface(folder, order_asc, order_desc, driver)
    except OrderError as exception:
        print(f'Error: {exception}')
        exit(1)


if __name__ == '__main__':
    args = parse_cli_args()
    folder = args.files
    order_asc = args.asc
    order_desc = args.desc
    driver = args.driver

    main(folder, order_asc, order_desc, driver)
