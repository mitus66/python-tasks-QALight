import json
from datetime import datetime, timedelta
import os
import requests

from package_test.dto import FuncParamDTO
from package_test.types import EpisodesType, EpisodesPaginatedType


def fetch_episodes(url: str) -> dict:
    response = requests.get(url)
    return response.json()


def parse_response_episodes(response: dict) -> EpisodesType:
    return response['results']


def check_episodes_cache(filepath: str, minutes: int = 100) -> bool:
    if os.path.isfile(filepath):
        last_modified = datetime.fromtimestamp(os.path.getmtime(filepath))
        if datetime.now() - last_modified < timedelta(minutes=minutes):
            return True
    return False


def dump_cache_episodes(filepath: str, episodes: EpisodesType) -> None:
    with open(filepath, 'w') as file:
        json.dump(episodes, file, indent=4)


def load_cache_episodes(filepath: str) -> EpisodesType:
    with open(filepath) as file:
        data = json.load(file)
    return data


def sort_episodes(episodes: EpisodesType, field: str, reverse: bool = False) -> EpisodesType:
    sorted_episodes = sorted(episodes, key=lambda episode: episode.get(field, 0), reverse=reverse)
    return sorted_episodes


def paginate_episodes(episodes: EpisodesType, per_page: int) -> EpisodesPaginatedType:
    paginated_result = [episodes[i:i + per_page] for i in range(0, len(episodes), per_page)]
    return paginated_result


def main(params: FuncParamDTO):
    if not check_episodes_cache(params.filepath, params.minutes):
        response_data = fetch_episodes(params.url)
        episodes = parse_response_episodes(response_data)
        dump_cache_episodes(params.filepath, episodes)
    else:
        episodes = load_cache_episodes(params.filepath)
    episodes_sorted = sort_episodes(episodes, params.sort_field, params.sort_reverse)
    paginated_result = paginate_episodes(episodes_sorted, params.per_page)
    return paginated_result


if __name__ == '__main__':
    url_episodes = 'https://rickandmortyapi.com/api/episode/'
    episodes_file = 'episodes.json'
    cache_time = 100
    sort_field = 'id'
    sort_reverse = False
    per_page = 2

    func_params = FuncParamDTO(
        url=url_episodes,
        filepath=episodes_file,
        minutes=cache_time,
        sort_field=sort_field,
        sort_reverse=sort_reverse,
        per_page=per_page
    )

    episodes_result = main(func_params)

    for episode in episodes_result:
        print(episode)
