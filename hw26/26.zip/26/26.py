import pygame
import pygame_menu
from random import randrange

# Ваш код ініціалізації...

def start_the_game():
    # Ваш код для початку гри...

def pause_the_game():
    # Ваш код для паузи гри...

def end_the_game():
    # Ваш код для закінчення гри...

menu = pygame_menu.Menu(300, 400, 'Welcome',
                       theme=pygame_menu.themes.THEME_BLUE)

menu.add_button('Play', start_the_game)
menu.add_button('Pause', pause_the_game)
menu.add_button('Quit', end_the_game)

menu.mainloop(surface)