from exceptions import OrderError


def main(folder: str, order_asc: bool = True, order_desc: bool = False, driver: str = ''):
    if order_asc and order_desc:
        raise OrderError('Two sorting args simultaneously')

    # your code

