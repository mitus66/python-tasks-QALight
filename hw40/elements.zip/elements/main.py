import re
from pathlib import Path
from typing import NamedTuple, Optional
from string import punctuation

from prettytable import PrettyTable


class Element(NamedTuple):
    num: int
    abbr: str
    name: str


def check_file(filepath: str) -> bool:
    """Check if file exists and has text format"""
    try:
        open(filepath, 'rt').readline()
    except FileNotFoundError as exception:
        print(exception)
        return False
    except UnicodeDecodeError:
        print(f'File {filepath}. Is not a text.')
        return False
    return True


def check_element_format(element: str) -> bool:
    # LOOK HERE #######################
    # Changed re.search() to re.match()
    match = re.match(r'^[0-9]{1,3},([A-Z]|[A-Z][a-z]{1,2}),[A-Z][a-z]+$', element)
    ###################################
    return True if match else False


def read_elements_from_file(filepath: str) -> list[Element]:
    elements = []
    with open(filepath) as elements_file:
        for element in elements_file:
            element = element.strip().strip(punctuation)
            # AND HERE #################################
            # Changed main "if" from "if not" to "if"
            # Added additional "if" to print elements with errors
            if not check_element_format(element):
                print(f'Error in element - {element}')
            if check_element_format(element):
                num, abbr, name = element.split(',')
                elements.append(Element(num, abbr, name))
            #############################################
    return elements


def find_element(elements: list[Element], user_search: str) -> Optional[Element]:
    result_element = [element
                      for element in elements
                      if user_search.capitalize() in element]
    return result_element.pop() if result_element else None


def print_element(element: Element) -> None:
    table = PrettyTable()
    table.field_names = ('Num', 'Abbr', 'Name')
    table.add_row((element.num, element.abbr, element.name))

    print(table)


def main(filepath: str, user_search: str) -> None:
    if not check_file(filepath):
        return None
    elements = read_elements_from_file(filepath)
    user_element = find_element(elements, user_search)

    if not user_element:
        print(f'Element: {user_search} not found')
        return None
    print_element(user_element)


if __name__ == '__main__':
    file = 'elements.txt'
    filepath1 = str(Path(__file__).parent.joinpath('data').joinpath(file))
    user_search1 = 'Na'
    main(filepath1, user_search1)
