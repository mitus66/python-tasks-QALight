"""Report framework works with  f1 race data"""
import os
import sys
from pathlib import Path

# path = Path(os.getcwd())
# fpath = os.path.join(path, 'report_framework')
# sys.path.append(fpath)
